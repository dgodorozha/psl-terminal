# Verifying this evidence pack

1. Check the manifest: every file's SHA-256 is listed in `manifest.json`.
   `python -c "import json,hashlib,sys; m=json.load(open('manifest.json'));
   [print(f, hashlib.sha256(open(f,'rb').read()).hexdigest()==h) for f,h in m['files'].items()]"`
2. Replay the ledger chain: `python -m psl.ledger verify ledger.jsonl`.
   Set `PSL_SECRET` to the server secret to also check the signatures.
3. Reproduce the numbers: the battery is in `battery.json` with its seed,
   horizon and path count, and every value judgement is in
   `assumptions.json`. `python -m psl.orchestrator --battery battery.json
   --approve-battery --approve-briefing --preparer "<name>" --preparer-role
   "<function>" --approver "<name>" --approver-role "<function>" --outdir
   replay` recomputes `artefacts.json`; the welfare, safety and market
   figures should match to the printed precision, and the
   `code_fingerprint` in `provenance` should match the code you run.
4. The briefing was drafted only from `artefacts.json`; `critic.json` lists
   the checks that passed before release, including the vetting of every
   number in the briefing against the artefacts.
